package com.example.projecttwo;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;

public class DataActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    EditText itemNameField, quantityField;
    Button addButton, smsScreenButton;
    ListView listView;
    ArrayList<Item> itemList;
    ItemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // Initialize database and UI components
        dbHelper = new DatabaseHelper(this);
        itemNameField = findViewById(R.id.itemNameField);
        quantityField = findViewById(R.id.quantityField);
        addButton = findViewById(R.id.addButton);
        smsScreenButton = findViewById(R.id.smsScreenButton);
        listView = findViewById(R.id.listView);

        // Set up list adapter
        itemList = new ArrayList<>();
        adapter = new ItemAdapter(this, itemList, dbHelper);
        listView.setAdapter(adapter);

        // Load any saved items from the database
        loadItems();

        // Add button handler
        addButton.setOnClickListener(v -> {
            String name = itemNameField.getText().toString().trim();
            String qtyStr = quantityField.getText().toString().trim();

            if (name.isEmpty() || qtyStr.isEmpty()) {
                Toast.makeText(this, "Enter all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            int qty;
            try {
                qty = Integer.parseInt(qtyStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Quantity must be a number", Toast.LENGTH_SHORT).show();
                return;
            }

            if (dbHelper.insertItem(name, qty)) {
                Toast.makeText(this, "Item added", Toast.LENGTH_SHORT).show();
                loadItems();
                itemNameField.setText("");
                quantityField.setText("");
            } else {
                Toast.makeText(this, "Failed to add item", Toast.LENGTH_SHORT).show();
            }
        });

        // Navigate to SMS Activity
        smsScreenButton.setOnClickListener(v -> {
            Intent intent = new Intent(DataActivity.this, SmsActivity.class);
            startActivity(intent);
        });
    }

    private void loadItems() {
        itemList.clear();
        Cursor cursor = dbHelper.getAllItems();

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                int qty = cursor.getInt(2);
                itemList.add(new Item(id, name, qty));
            }
            cursor.close();
        }

        adapter.notifyDataSetChanged();
    }
}
