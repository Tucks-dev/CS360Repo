package com.example.projecttwo;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class ItemAdapter extends BaseAdapter {

    Context context;
    ArrayList<Item> itemList;
    DatabaseHelper dbHelper;

    public ItemAdapter(Context context, ArrayList<Item> itemList, DatabaseHelper dbHelper) {
        this.context = context;
        this.itemList = itemList;
        this.dbHelper = dbHelper;
    }

    @Override
    public int getCount() {
        return itemList.size();
    }

    @Override
    public Object getItem(int position) {
        return itemList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return itemList.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_item, parent, false);

        TextView itemName = view.findViewById(R.id.itemName);
        TextView quantity = view.findViewById(R.id.quantity);
        Button deleteBtn = view.findViewById(R.id.deleteBtn);
        Button editBtn = view.findViewById(R.id.editBtn);

        Item item = itemList.get(position);
        itemName.setText(item.getName());
        quantity.setText(String.valueOf(item.getQuantity()));

        deleteBtn.setOnClickListener(v -> {
            if (dbHelper.deleteItem(item.getId())) {
                Toast.makeText(context, "Item deleted", Toast.LENGTH_SHORT).show();
                itemList.remove(position);
                notifyDataSetChanged();
            }
        });

        editBtn.setOnClickListener(v -> {
            showEditDialog(item);
        });

        return view;
    }

    private void showEditDialog(Item item) {
        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_edit_item, null);
        EditText nameField = dialogView.findViewById(R.id.editItemName);
        EditText qtyField = dialogView.findViewById(R.id.editQuantity);
        Button saveBtn = dialogView.findViewById(R.id.saveEditBtn);

        nameField.setText(item.getName());
        qtyField.setText(String.valueOf(item.getQuantity()));

        AlertDialog dialog = new AlertDialog.Builder(context)
                .setView(dialogView)
                .create();

        saveBtn.setOnClickListener(v -> {
            String newName = nameField.getText().toString().trim();
            int newQty = Integer.parseInt(qtyField.getText().toString().trim());
            if (dbHelper.updateItem(item.getId(), newName, newQty)) {
                Toast.makeText(context, "Item updated", Toast.LENGTH_SHORT).show();
                item.setName(newName);
                item.setQuantity(newQty);
                notifyDataSetChanged();
                dialog.dismiss();
            }
        });

        dialog.show();
    }
}
